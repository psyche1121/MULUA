# GameServer Lua API Documentation

This document provides a comprehensive, exhaustive reference for all Lua functions, classes, properties, and constants exposed in the GameServer's `LuaManager.cpp`.

---

## Table of Contents

1. [Global Functions](#global-functions)
    - [Utility Functions & Constants](#utility-functions--constants)
    - [User Management](#user-management)
    - [Item & Inventory Management](#item--inventory-management)
    - [Monster & Map Management](#monster--map-management)
    - [Skill & Master Skill Tree](#skill--master-skill-tree)
    - [Effect Management](#effect-management)
    - [Party, Guild & Chat](#party-guild--chat)
    - [Duel & PVP](#duel--pvp)
    - [Viewport & Networking](#viewport--networking)
    - [Events & Quests](#events--quests)
2. [Classes & Objects](#classes--objects)
    - [GameObject (User/Monster)](#gameobject-user--monster)
    - [GameItem](#gameitem)
    - [GameCEffect](#gameceffect)
    - [GameEffectOption](#gameeffectoption)
    - [Packet](#packet)
3. [Event Hooks (Callbacks)](#event-hooks-callbacks)
4. [Constants](#constants)

---

## Global Functions

### Utility Functions & Constants
 
**LogAdd(color, message)**
*   `color` = Color code (2=Red, 3=Green, 4=Blue). "Integer"
*   `message` = Text to log. "String"
*   Logs a message to the server console. Return "Void".
 
**GetTickCount()**
*   Returns system uptime in milliseconds. "DWORD"
 
**GetLargeRand(val)**
*   `val` = Max value (exclusive). "Integer"
*   Returns random number 0 to val-1. Handles large numbers. "Integer"
 
**rand(val)**
*   `val` = Max value (exclusive). "Integer"
*   Returns random number 0 to val-1. "Integer"
 
**MAX_OBJECT_MONSTER**
*   Constant: Max Monsters. "Integer"
 
**MAX_OBJECT_USER**
*   Constant: Max Users. "Integer"
 
**MAX_OBJECT_SUMMON**
*   Constant: Max Summons. "Integer"
 
**MAX_OBJECT**
*   Constant: Max Total Objects. "Integer"
 
**OBJECT_START_MONSTER**
*   Constant: Monster Start Index. "Integer"
 
**OBJECT_START_USER**
*   Constant: User Start Index. "Integer"
 
**OBJECT_RANGE(index)**
*   `index` = Object Index. "Integer"
*   Returns (true) if index is valid. "Boolean"
 
**OBJECT_MONSTER_RANGE(index)**
*   `index` = Monster Index. "Integer"
*   Returns (true) if index is a monster. "Boolean"
 
**OBJECT_SUMMON_RANGE(index)**
*   `index` = Summon Index. "Integer"
*   Returns (true) if index is a summon. "Boolean"
 
**OBJECT_USER_RANGE(index)**
*   `index` = User Index. "Integer"
*   Returns (true) if index is a user. "Boolean"
 
**SET_NUMBERHB(val)**
*   `val` = Number to check. "Integer"
*   Returns High Byte. "BYTE"
 
**SET_NUMBERLB(val)**
*   `val` = Number to check. "Integer"
*   Returns Low Byte. "BYTE"
 
**SET_NUMBERHW(val)**
*   `val` = Number to check. "Integer"
*   Returns High Word. "WORD"
 
**SET_NUMBERLW(val)**
*   `val` = Number to check. "Integer"
*   Returns Low Word. "WORD"
 
**SET_NUMBERHDW(val)**
*   `val` = Number (Double). "Double"
*   Returns High Double Word. "DWORD"
 
**SET_NUMBERLDW(val)**
*   `val` = Number (Double). "Double"
*   Returns Low Double Word. "DWORD"
 
**GetLevelExperience(level)**
*   `level` = Character Level. "Integer"
*   Returns required experience. "QWORD"
 
**GetMasterLevelExp(level)**
*   `level` = Master Level. "Integer"
*   Returns required master experience. "QWORD"
 
 
### User Management
 
**GetUser(index)**
*   `index` = User Index. "Integer"
*   Returns the `GameObject` (LPOBJ). "GameObject"
 
**gObjAllLogOut()**
*   Force logs out all users. Return "Void".
 
**gObjAllDisconnect(type)**
*   `type` = Disconnect reason. "Integer"
*   Disconnects all users. Return "Void".
 
**UserLogOut(index)**
*   `index` = User Index. "Integer"
*   Starts logout process. "Boolean"
 
**UserDisconnect(index, type)**
*   `index` = User Index. "Integer"
*   `type` = Disconnect reason. "Integer"
*   Force disconnects user. "Boolean"
 
**UserLogOutByName(name)**
*   `name` = Character Name. "String"
*   Logs out user by name. "Boolean"
 
**UserDisconnectByName(name, type)**
*   `name` = Character Name. "String"
*   `type` = Disconnect reason. "Integer"
*   Disconnects user by name. "Boolean"
 
**UserKick(index, reason)**
*   `index` = User Index. "Integer"
*   `reason` = Kick message/reason. "String"
*   Kicks user (returns to server select). "Boolean"
 
**UserKickByName(name, reason)**
*   `name` = Character Name. "String"
*   `reason` = Kick message/reason. "String"
*   Kicks user by name. "Boolean"
 
**gObjDel(index)**
*   `index` = User Index. "Integer"
*   Deletes object from system. "Integer"
 
**gObjFind(name)**
*   `name` = Character Name. "String"
*   Finds object by name. Returns `GameObject` or nil. "GameObject"
 
**gObjGetRandomFreeLocation(map, ox, oy, tx, ty, cnt)**
*   `map` = Map Number. "Integer"
*   `ox`, `oy` = Origin X, Y. "Integer"
*   `tx`, `ty` = Target X, Y range/buffer. "Integer"
*   `cnt` = Loop count check. "Integer"
*   Finds random free coord. "Boolean"
 
**gObjCalcDistance(obj1, obj2)**
*   `obj1` = Object 1. "GameObject"
*   `obj2` = Object 2. "GameObject"
*   Calculates distance. "Integer"
 
**gObjCalcDistance(x1, y1, x2, y2)**
*   `x1`, `y1` = Coord 1. "Integer"
*   `x2`, `y2` = Coord 2. "Integer"
*   Calculates distance. "Integer"
 
**gObjIsConnected(index)**
*   `index` = User Index. "Integer"
*   Checks if index is connected. "Boolean"
 
**gObjIsConnectedGP(index)**
*   `index` = User Index. "Integer"
*   Checks if connected to GameServer. "Boolean"
 
**gObjIsConnectedGS(index)**
*   `index` = User Index. "Integer"
*   Checks if connected to GameServer (alt). "Boolean"
 
**gObjIsNameValid(index, name)**
*   `index` = User Index. "Integer"
*   `name` = Name to check. "String"
*   Validates character name. "Boolean"
 
**gObjIsAccountValid(index, acc)**
*   `index` = User Index. "Integer"
*   `acc` = Account Name. "String"
*   Validates account. "Boolean"
 
**gObjIsChangeSkin(index)**
*   `index` = User Index. "Integer"
*   Checks if skin is changed. "Boolean"
 
**gObjCheckMaxMoney(index)**
*   `index` = User Index. "Integer"
*   Checks/Fixes max money. "Boolean"
 
**gObjCheckPersonalCode(index, code)**
*   `index` = User Index. "Integer"
*   `code` = Personal Code. "String"
*   Checks personal code. "Boolean"
 
**gObjCheckResistance(obj, type)**
*   `obj` = User Object. "GameObject"
*   `type` = Resistance type. "Integer"
*   Gets resistance value. "Integer"
 
**gObjCheckTeleportArea(obj, x, y)**
*   `obj` = User Object. "GameObject"
*   `x`, `y` = Coordinates. "Integer"
*   Checks teleport validity. "Boolean"
 
**gObjCheckMapTile(obj, type)**
*   `obj` = User Object. "GameObject"
*   `type` = Attribute type to check. "Integer"
*   Checks map attribute under feet. "Boolean"
 
**gObjCheckWarStatus(obj)**
*   `obj` = User Object. "GameObject"
*   Checks Guild War status. "Boolean"
 
**gObjCheckDuelStatus(obj)**
*   `obj` = User Object. "GameObject"
*   Checks Duel status. "Boolean"
 
**gObjSetKillCount(index, type)**
*   `index` = User Index. "Integer"
*   `type` = PK Type. "Integer"
*   Sets PK/Hero count. "Void"
 
**gObjTeleportMagicUse(obj, rx, ry)**
*   `obj` = User Object. "GameObject"
*   `rx`, `ry` = Coordinates. "Integer"
*   Executes teleport skill. "Void"
 
**gObjUserDie(obj)**
*   `obj` = User Object. "GameObject"
*   Kills the user. "Void"
 
**gObjPlayerKiller(obj, target)**
*   `obj` = Attacker/Killer. "GameObject"
*   `target` = Victim. "GameObject"
*   Processes PK logic. "Void"
 
**gObjMoveGate(index, gate)**
*   `index` = User Index. "Integer"
*   `gate` = Gate Number. "Integer"
*   Moves user to gate. "Integer"
 
**gObjTeleport(index, map, x, y)**
*   `index` = User Index. "Integer"
*   `map` = Map Number. "Integer"
*   `x`, `y` = Coordinates. "Integer"
*   Teleports user. "Void"
 
**MoveObjectTo(obj, map, x, y, help)**
*   `obj` = User Object. "GameObject"
*   `map`, `x`, `y` = Destination. "Integer"
*   `help` = Help/Push flag. "Bool"
*   Teleports user (Advanced). "Void"
 
**gObjSummonAlly(obj, map, x, y)**
*   `obj` = User Object. "GameObject"
*   `map`, `x`, `y` = Destination. "Integer"
*   Summons party/guild ally. "Void"
 
**gObjSkillUseProc(obj, skill, target...)**
*   `obj` = User Object. "GameObject"
*   `skill` = Skill Struct/ID. "Integer"
*   Processes skill use. "Void"
 
**gObjUserKill(index)**
*   `index` = User Index. "Integer"
*   Force kill connection. "Void"
 
**gObjSearchDuplicateItem(obj, serial)**
*   `obj` = User Object. "GameObject"
*   `serial` = Item Serial. "Integer"
*   Checks for duped items. "Boolean"
 
**gObjAddMsgSend(obj, msg...)**
*   `obj` = User Object. "GameObject"
*   `msg` = Message data. "Packet/String"
*   Sends message packet. "Void"
 
**gObjAddMsgSendDelay(obj, msg...)**
*   `obj` = User Object. "GameObject"
*   `msg` = Message data. "Packet/String"
*   Sends message packet with delay. "Void"
 
**gObjAddAttackProcMsgSendDelay(obj, msg...)**
*   `obj` = User Object. "GameObject"
*   `msg` = Msg. "Packet"
*   Sends attack msg with delay. "Void"
 
**gObjAddFuncionDelay(obj, funcId, delay)**
*   `obj` = User Object. "GameObject"
*   `funcId` = Function ID. "Integer"
*   `delay` = Milliseconds. "Integer"
*   Delays function execution. "Void"
 
**gObjBackSpring(obj, target)**
*   `obj` = User Object. "GameObject"
*   `target` = Target Object. "GameObject"
*   Knockback effect. "Void"
 
**gObjBackSpring2(obj, target, count)**
*   `obj` = User Object. "GameObject"
*   `target` = Target Object. "GameObject"
*   `count` = Tiles to push. "Integer"
*   Knockback effect 2. "Void"
 
**BackSpringCheck(map, x, y)**
*   `map`, `x`, `y` = Location. "Integer"
*   Checks knockback validity. "Tuple"
 
**gObjCheckBackSpining(obj)**
*   `obj` = User Object. "GameObject"
*   Checks if currently knockbacking. "Boolean"
 
**gObjIsSelfDefense(obj, target)**
*   `obj` = User Object. "GameObject"
*   `target` = Target Object. "GameObject"
*   Checks self-defense status. "Boolean"
 
**gObjCheckSelfDefense(obj, target)**
*   `obj` = User Object. "GameObject"
*   `target` = Target Object. "GameObject"
*   Activates self-defense. "Void"
 
**gObjTimeCheckSelfDefense(obj)**
*   `obj` = User Object. "GameObject"
*   Updates self-defense timer. "Void"
 
**gObjUseDrink(obj, pos)**
*   `obj` = User Object. "GameObject"
*   `pos` = Inventory Position. "Integer"
*   Uses potion/item. "Void"
 
**gObjCheckAutoParty(obj, leader)**
*   `obj` = User Object. "GameObject"
*   `leader` = Party Leader Object. "GameObject"
*   Checks auto-party logic. "Boolean"
 
**gObjGetMountIndex(item)**
*   `item` = Item Object/ID. "Integer"
*   Gets mount ID from item. "Integer"
 
**GetMountIndex(obj)**
*   `obj` = User Object. "GameObject"
*   Gets mount ID from user. "Integer"
 
**GetMountSlot(obj)**
*   `obj` = User Object. "GameObject"
*   Gets mount slot index. "Integer"
 
**gObjGetPositionTarget(obj, tx, ty)**
*   `obj` = User Object. "GameObject"
*   `tx`, `ty` = Target X, Y. "Integer"
*   Gets target coordinates. "Tuple"
 
**gObjCharacterReduceZen(obj, amt)**
*   `obj` = User Object. "GameObject"
*   `amt` = Amount. "Integer"
*   Reduces Zen. "Boolean"
 
**gObjCharacterAddZen(obj, amt)**
*   `obj` = User Object. "GameObject"
*   `amt` = Amount. "Integer"
*   Adds Zen. "Void"
 
**gObjCharacterSetZen(obj, amt)**
*   `obj` = User Object. "GameObject"
*   `amt` = Amount. "Integer"
*   Sets Zen. "Void"
 
**gObjCharacterReduceRuud(obj, amt)**
*   `obj` = User Object. "GameObject"
*   `amt` = Amount. "Integer"
*   Reduces Ruud. "Boolean"
 
**gObjCharacterAddRuud(obj, amt)**
*   `obj` = User Object. "GameObject"
*   `amt` = Amount. "Integer"
*   Adds Ruud. "Void"
 
**gObjCharacterSetRuud(obj, amt)**
*   `obj` = User Object. "GameObject"
*   `amt` = Amount. "Integer"
*   Sets Ruud. "Void"
 
**CashShopAddPoint(index, wc, wp, gp)**
*   `index` = User Index. "Integer"
*   `wc` = WCoin. "Integer"
*   `wp` = WCoinP. "Integer"
*   `gp` = Goblin Point. "Integer"
*   Adds CashShop points. "Void"
 
**CheckAbilityLevel(obj)**
*   `obj` = User Object. "GameObject"
*   Checks Ability Level. "Boolean"
 
**UserCalcAttribute(index)**
*   `index` = User Index. "Integer"
*   Recalculates character stats. "Boolean"
 
**UserInfoSend(index)**
*   `index` = User Index. "Integer"
*   Sends updated user info to client. "Boolean"
 
**LevelUpSend(index)**
*   `index` = User Index. "Integer"
*   Processes level up effect and packet. "Boolean"
 
**MasterLevelUpSend(index)**
*   `index` = User Index. "Integer"
*   Processes master level up. "Boolean"
 
**PKLevelSend(index, pkLevel)**
*   `index` = User Index. "Integer"
*   `pkLevel` = New PK Level. "Integer"
*   Sets and sends PK level. "Boolean"
 
**CharacterSkinSend(index, monsterId)**
*   `index` = User Index. "Integer"
*   `monsterId` = Monster Skin ID (-1 to reset). "Integer"
*   Changes character skin. "Boolean"

### Item & Inventory Management

### Item & Inventory Management
 
**GET_ITEM(group, index)**
*   `group` = Item Section (0-15). "Integer"
*   `index` = Item Index. "Integer"
*   Returns Item ID (Section*512 + Index). "Integer"
 
**ItemGive(index, itemValue)**
*   `index` = User Index. "Integer"
*   `itemValue` = Item ID. "Integer"
*   Gives an item to user. "Boolean"
 
**ItemGiveEx(index, id, lvl, dur, opt1, opt2, opt3, newOpt, setOpt, joh, ex, s1, s2, s3, s4, s5, bonus, duration)**
*   `index` = User Index. "Integer"
*   `id` = Item ID. "Integer"
*   `lvl` = Level (0-15). "Integer"
*   `dur` = Durability (0-255). "Integer"
*   `opt1` = Skill (0/1). "Integer"
*   `opt2` = Luck (0/1). "Integer"
*   `opt3` = Option (0-7). "Integer"
*   `newOpt` = Excellent Options. "Integer"
*   `setOpt` = Ancient Set Index. "Integer"
*   `joh` = Jewel of Harmony Option. "Integer"
*   `ex` = Extended Option. "Integer"
*   `s1`...`s5` = Socket Options. "Integer"
*   `bonus` = Bonus Value. "Integer"
*   `duration` = Period Time. "Integer"
*   Gives a fully customized item. "Boolean"
 
**ItemDrop(index, map, x, y, itemId)**
*   `index` = User Index. "Integer"
*   `map`, `x`, `y` = Location. "Integer"
*   `itemId` = Item ID. "Integer"
*   Drops a specific item on the ground. "Boolean"
 
**ItemDropEx(index, map, x, y, id, lvl, dur, ...)**
*   `index` = User Index. "Integer"
*   `map`, `x`, `y` = Location. "Integer"
*   `id`... = Item Attributes (Same as ItemGiveEx). "Integer"
*   Drops a fully customized item. "Boolean"
 
**MoneyDrop(index, map, x, y, amount)**
*   `index` = User Index. "Integer"
*   `map`, `x`, `y` = Location. "Integer"
*   `amount` = Zen Amount. "Integer"
*   Drops Zen on the ground. "Boolean"
 
**CheckItemFromSpecialValue(specialValue)**
*   `specialValue` = Bag/Event Value. "Integer"
*   Checks if a special item value exists. "Boolean"
 
**GetItemFromItemBag(index, specialValue)**
*   `index` = User Index. "Integer"
*   `specialValue` = Bag Value. "Integer"
*   Gives item from bag special value. "Boolean"
 
**InventoryGetItemCount(index, id, level)**
*   `index` = User Index. "Integer"
*   `id` = Item ID. "Integer"
*   `level` = Item Level (-1 for any). "Integer"
*   Counts specific items in inventory. "Integer"
 
**InventoryDelItemIndex(index, slot)**
*   `index` = User Index. "Integer"
*   `slot` = Inventory Slot (0-236). "Integer"
*   Deletes item in specific slot. "Boolean"
 
**InventoryDelItemCount(index, id, lvl, count)**
*   `index` = User Index. "Integer"
*   `id` = Item ID. "Integer"
*   `lvl` = Item Level (-1 for any). "Integer"
*   `count` = Amount to delete. "Integer"
*   Deletes specific quantity of items. "Boolean"
 
**InventoryGetFreeSlotCount(index)**
*   `index` = User Index. "Integer"
*   Returns number of free inventory slots. "Integer"
 
**InventoryCheckSpaceByItem(index, itemId)**
*   `index` = User Index. "Integer"
*   `itemId` = Item ID to check size. "Integer"
*   Checks if user has space for item. "Boolean"
 
**InventoryCheckSpaceBySize(index, w, h)**
*   `index` = User Index. "Integer"
*   `w`, `h` = Width, Height. "Integer"
*   Checks if user has space for size. "Boolean"
 
**GDWareHouseReducePenaltyMoney(obj, money)**
*   `obj` = User Object. "GameObject"
*   `money` = Amount. "Integer"
*   Reduces warehouse money (Guild Penalty). "Void"
 
**CGItemDropRecv(obj, slot, x, y, mode)**
*   `obj` = User Object. "GameObject"
*   `slot` = Inv Slot. "Integer"
*   `x`, `y` = Coordinates. "Integer"
*   `mode` = Drop Mode. "Integer"
*   Simulates client request to drop item. "Boolean"
 
**gObjFixInventoryPointer(index)**
*   `index` = User Index. "Integer"
*   Fixes inventory memory pointers. "Void"
 
**gObjSearchDuplicateItem(obj, serial)**
*   `obj` = User Object. "GameObject"
*   `serial` = Item Serial. "Integer"
*   Checks for duplicate items. "Boolean"
 
 
### Monster & Map Management
 
**gObjMonsterDieGiveItem(group, userIndex)**
*   `group` = Monster Group/ID. "Integer"
*   `userIndex` = Killer Index. "Integer"
*   Processes item drop on death. "Void"
 
**gObjSetPosMonster(index, map, x, y)**
*   `index` = Monster Index. "Integer"
*   `map`, `x`, `y` = Location. "Integer"
*   Sets monster position. "Void"
 
**gObjSetMonster(index, number)**
*   `index` = Object Index. "Integer"
*   `number` = Monster ID (Class). "Integer"
*   Initializes monster by number. "Void"
 
**gObjMonsterRegen(index)**
*   `index` = Monster Index. "Integer"
*   Respawns/Regens monster. "Void"
 
**gObjMonsterMoveCheck(obj, tx, ty)**
*   `obj` = Monster Object. "GameObject"
*   `tx`, `ty` = Target X, Y. "Integer"
*   Checks move validity. "Boolean"
 
**gObjMonsterInitHitDamage(obj)**
*   `obj` = Monster Object. "GameObject"
*   Initializes hit damage list. "Void"
 
**gObjMonsterResetHitDamage(obj)**
*   `obj` = Monster Object. "GameObject"
*   Resets hit damage list. "Void"
 
**gObjMonsterDelHitDamageUser(obj)**
*   `obj` = Monster Object. "GameObject"
*   Clears hit damage by user. "Void"
 
**gObjMonsterGetTopHitDamageUser(obj)**
*   `obj` = Monster Object. "GameObject"
*   Gets user index with most damage. "Integer"
 
**gObjAddMonster(map)**
*   `map` = Map Number. "Integer"
*   Adds a new monster object to map. Returns Index. "Integer"
 
**gObjAddSummon(val)**
*   `val` = Summon ID/Data. "Integer"
*   Adds a summoned monster. "Void"
 
**gObjSummonSetEnemy(obj, target)**
*   `obj` = Summon Object. "GameObject"
*   `target` = Target Object. "GameObject"
*   Sets summon's enemy. "Void"
 
**gObjSummonKill(index)**
*   `index` = Summon Index. "Integer"
*   Kills summoned monster. "Void"
 
**gObjFieldKill(obj, target)**
*   `obj` = Monster Object. "GameObject"
*   `target` = Killer Object. "GameObject"
*   Kills field monster. "Void"
 
**gObjMonsterMagicAttack(index, targetIndex)**
*   `index` = Attacker Index. "Integer"
*   `targetIndex` = Target Index. "Integer"
*   Executes magic attack. "Void"
 
**gObjMonsterAttack(index, targetIndex)**
*   `index` = Attacker Index. "Integer"
*   `targetIndex` = Target Index. "Integer"
*   Executes physical attack. "Void"
 
**gObjMonsterDie(index, killerIndex)**
*   `index` = Dying Object. "Integer"
*   `killerIndex` = Killer Object. "Integer"
*   Triggers monster death. "Void"
 
**gObjMonsterStateProc(obj, code, a, b)**
*   `obj` = Monster Object. "GameObject"
*   `code` = State Code. "Integer"
*   `a`, `b` = State Args. "Integer"
*   Processes monster state/AI. "Void"
 
**gObjIsBossMonster(index)**
*   `index` = Monster Index. "Integer"
*   Checks if monster is a boss. "Boolean"
 
**gObjMonsterSelectSkillForMedusa(obj)**
*   `obj` = Monster Object. "GameObject"
*   AI for Medusa skill selection. "Void"
 
**gObjMonsterViewportIsCharacter(obj)**
*   `obj` = Monster Object. "GameObject"
*   Checks if viewport has players. "Boolean"
 
**gObjMonsterGetTargetPos(obj)**
*   `obj` = Monster Object. "GameObject"
*   Gets target position. "Tuple"
 
**gObjMonsterSearchEnemy(obj, type)**
*   `obj` = Monster Object. "GameObject"
*   `type` = Search Type. "Integer"
*   Searches for enemy. "Integer"
 
**gObjCheckMonsterSearchEnemy(obj, target)**
*   `obj` = Monster Object. "GameObject"
*   `target` = Target Object. "GameObject"
*   Checks if target is valid enemy. "Boolean"
 
**gObjGuardSearchEnemy(obj)**
*   `obj` = Guard Object. "GameObject"
*   Guard AI search. "Integer"
 
**gObjMonsterProcess(obj)**
*   `obj` = Monster Object. "GameObject"
*   Main monster processing loop. "Void"
 
**PathFindMoveMsgSend(obj)**
*   `obj` = Monster Object. "GameObject"
*   Sends pathfinding move packet. "Void"
 
**gObjMonsterMoveAction(obj)**
*   `obj` = Monster Object. "GameObject"
*   Executes move action. "Void"
 
**gObjMonsterBaseAct(obj)**
*   `obj` = Monster Object. "GameObject"
*   Base monster action. "Void"
 
**gObjTrapAttackEnemySearchX(obj, cnt)**
*   `obj` = Trap Object. "GameObject"
*   `cnt` = Range X. "Integer"
*   Trap search X. "Integer"
 
**gObjTrapAttackEnemySearchY(obj, cnt)**
*   `obj` = Trap Object. "GameObject"
*   `cnt` = Range Y. "Integer"
*   Trap search Y. "Integer"
 
**gObjTrapAttackEnemySearch(obj)**
*   `obj` = Trap Object. "GameObject"
*   Trap search generic. "Integer"
 
**gObjMonsterTrapAct(obj)**
*   `obj` = Trap Object. "GameObject"
*   Trap action logic. "Void"
 
**gObjMonsterWeaknessAct(obj)**
*   `obj` = Monster Object. "GameObject"
*   Weakness event action. "Void"
 
**gObjMonsterInnovationAct(obj)**
*   `obj` = Monster Object. "GameObject"
*   Innovation event action. "Void"
 
**gObjMonsterMagicFieldPoison(obj, idx...)**
*   `obj` = Monster Object. "GameObject"
*   `idx`... = Targets. "Integer"
*   Spawns Poison field. "Void"
 
**gObjMonsterMagicFieldChilling(obj, idx...)**
*   `obj` = Monster Object. "GameObject"
*   Spawns Chilling field. "Void"
 
**gObjMonsterMagicFieldBleeding(obj, idx...)**
*   `obj` = Monster Object. "GameObject"
*   Spawns Bleeding field. "Void"
 
**gObjMonsterUnleashMarvelMainEnergy(obj)**
*   `obj` = Monster Object. "GameObject"
*   Unleashes boss energy. "Void"
 
**gObjMonsterSetHitDamage(obj, idx, dmg)**
*   `obj` = Monster Object. "GameObject"
*   `idx` = Attacker Index. "Integer"
*   `dmg` = Damage Amount. "Integer"
*   Records damage dealt by user. "Integer"
 
**gObjMonsterGetTopHitDamageParty(obj, party)**
*   `obj` = Monster Object. "GameObject"
*   `party` = Party Number. "Integer"
*   Gets top damage party/user. "Tuple"
 
**FindMonsterClassInVP(obj, class, dist)**
*   `obj` = Searcher Object. "GameObject"
*   `class` = Monster Class. "Integer"
*   `dist` = Distance. "Integer"
*   Finds monster class in viewport. "Boolean"
 
**FindMonsterCharacterInVP(obj, idx)**
*   `obj` = Searcher Object. "GameObject"
*   `idx` = Target Index. "Integer"
*   Finds character in viewport. "Boolean"
 
**MapCheckAttr(map, x, y, attr)**
*   `map`, `x`, `y` = Location. "Integer"
*   `attr` = Attribute (1=Safe, 4=NoMove, etc). "Integer"
*   Checks map attribute (Safe/Hunt). "Boolean"

### Skill & Master Skill Tree
 
### Skill & Master Skill Tree
 
**GetSkillDamage(skillIndex)**
*   `skillIndex` = Skill ID. "Integer"
*   Returns skill base damage. "Integer"
 
**GetSkillMana(skillIndex)**
*   `skillIndex` = Skill ID. "Integer"
*   Returns Mana cost. "Integer"
 
**GetSkillBP(skillIndex)**
*   `skillIndex` = Skill ID. "Integer"
*   Returns AG cost. "Integer"
 
**GetSkillType(skillIndex)**
*   `skillIndex` = Skill ID. "Integer"
*   Returns skill type. "Integer"
 
**GetSkillEffect(skillIndex)**
*   `skillIndex` = Skill ID. "Integer"
*   Returns skill effect index. "Integer"
 
**GetSkillRange(obj, skillIndex)**
*   `obj` = User Object. "GameObject"
*   `skillIndex` = Skill ID. "Integer"
*   Returns skill range. "Integer"
 
**GetSkillRadio(obj, skillIndex)**
*   `obj` = User Object. "GameObject"
*   `skillIndex` = Skill ID. "Integer"
*   Returns skill radius. "Integer"
 
**GetSkillDelay(skillIndex)**
*   `skillIndex` = Skill ID. "Integer"
*   Returns skill delay. "Integer"
 
**GetSkillDamageType(skillIndex)**
*   `skillIndex` = Skill ID. "Integer"
*   Returns damage type. "Integer"
 
**GetElementImprintBonus(skillIndex)**
*   `skillIndex` = Skill ID. "Integer"
*   Returns elemental imprint bonus. "Integer"
 
**GetAddDamageOption(skillIndex)**
*   `skillIndex` = Skill ID. "Integer"
*   Returns add damage option (Value). "Integer"
 
**GetSkillAngle(x, y, tx, ty)**
*   `x`, `y` = Origin. "Integer"
*   `tx`, `ty` = Target. "Integer"
*   Returns skill angle. "Integer"
 
**AttackDirection(aIndex, bIndex)**
*   `aIndex` = Attacker Index. "Integer"
*   `bIndex` = Defender Index. "Integer"
*   Calculates attack direction. "BYTE"
 
**GetDirectionAboutByte(dir)**
*   `dir` = Direction. "BYTE"
*   Normalizes direction byte. "BYTE"
 
**GetSkillNumber(index, level)**
*   `index` = Skill Item Index. "Integer"
*   `level` = Skill Item Level. "Integer"
*   Gets skill number from item. "Integer"
 
**GetSkillSlot(obj, index)**
*   `obj` = User Object. "GameObject"
*   `index` = Skill ID. "Integer"
*   Gets inventory slot of skill item. "Integer"
 
**GetSkillMultiCount(obj, skill)**
*   `obj` = User Object. "GameObject"
*   `skill` = Skill ID. "Integer"
*   Gets multi-skill target count. "Integer"
 
**CheckSkillMana(obj, skillIndex)**
*   `obj` = User Object. "GameObject"
*   `skillIndex` = Skill ID. "Integer"
*   Checks if user has enough Mana. "Boolean"
 
**CheckSkillBP(obj, skillIndex)**
*   `obj` = User Object. "GameObject"
*   `skillIndex` = Skill ID. "Integer"
*   Checks if user has enough AG. "Boolean"
 
**CheckSkillRange(obj, skill, x, y...)**
*   `obj` = User Object. "GameObject"
*   `skill` = Skill ID. "Integer"
*   `x`, `y` = Check Coords. "Integer"
*   Validates range. "Boolean"
 
**CheckSkillRadio(obj, skill, x...)**
*   `obj` = User Object. "GameObject"
*   `skill` = Skill ID. "Integer"
*   Validates radius. "Boolean"
 
**CheckAttackRange(atk, def, dist...)**
*   `atk` = Attacker. "GameObject"
*   `def` = Defender. "GameObject"
*   `dist` = Distance bonus. "Integer"
*   Validates attack range. "Boolean"
 
**CheckSkillDelay(obj, skill, type)**
*   `obj` = User Object. "GameObject"
*   `skill` = Skill ID. "Integer"
*   `type` = Check Type. "Integer"
*   Checks skill cooldown/delay. "Boolean"
 
**CheckSkillTarget(obj, aIndex, bIndex...)**
*   `obj` = User Object. "GameObject"
*   `aIndex` = Attacker. "Integer"
*   `bIndex` = Target. "Integer"
*   Checks if target is valid for skill. "Boolean"
 
**CheckSkillRequireLevel(obj, index)**
*   `obj` = User Object. "GameObject"
*   `index` = Skill ID. "Integer"
*   Checks level requirement. "Boolean"
 
**CheckSkillRequireEnergy(obj, index)**
*   `obj` = User Object. "GameObject"
*   `index` = Skill ID. "Integer"
*   Checks energy requirement. "Boolean"
 
**CheckSkillRequireLeadership(obj, index)**
*   `obj` = User Object. "GameObject"
*   `index` = Skill ID. "Integer"
*   Checks leadership requirement. "Boolean"
 
**CheckSkillRequireKillPoint(obj, index)**
*   `obj` = User Object. "GameObject"
*   `index` = Skill ID. "Integer"
*   Checks kill point requirement. "Boolean"
 
**CheckSkillRequireGuildStatus(obj, index)**
*   `obj` = User Object. "GameObject"
*   `index` = Skill ID. "Integer"
*   Checks guild status requirement. "Boolean"
 
**CheckSkillRequireClass(obj, index)**
*   `obj` = User Object. "GameObject"
*   `index` = Skill ID. "Integer"
*   Checks class requirement. "Boolean"
 
**CheckSkillRequireWeapon(obj, index)**
*   `obj` = User Object. "GameObject"
*   `index` = Skill ID. "Integer"
*   Checks weapon requirement. "Boolean"
 
**IsSkillItem(index)**
*   `index` = Item Index. "Integer"
*   Checks if item is a skill orb/scroll. "Boolean"
 
**AddSkillWeapon(obj, index, level)**
*   `obj` = User Object. "GameObject"
*   `index` = Skill ID. "Integer"
*   `level` = Skill Level. "Integer"
*   Adds weapon skill. "Integer"
 
**DelSkillWeapon(obj, index, level)**
*   `obj` = User Object. "GameObject"
*   `index` = Skill ID. "Integer"
*   `level` = Skill Level. "Integer"
*   Removes weapon skill. "Integer"
 
**AddSkill(obj, idx, lvl, grp)**
*   `obj` = User Object. "GameObject"
*   `idx` = Skill ID. "Integer"
*   `lvl` = Skill Level. "Integer"
*   `grp` = Group (usually 0). "Integer"
*   Adds a skill. "Integer"
 
**DelSkill(obj, index)**
*   `obj` = User Object. "GameObject"
*   `index` = Skill ID. "Integer"
*   Deletes a skill. "Integer"
 
**GetSkill(obj, index)**
*   `obj` = User Object. "GameObject"
*   `index` = Skill ID. "Integer"
*   Returns CSkill object. "CSkill*"
 
**GenerateSkill(obj, skill, target...)**
*   `obj` = User Object. "GameObject"
*   `skill` = Skill ID. "Integer"
*   `target` = Target X/Y/Index. "Integer"
*   Executes skill logic. "Void"
 
**GCSkillAttackSend(obj, skill, target...)**
*   `obj` = User Object. "GameObject"
*   `skill` = Skill ID. "Integer"
*   `target` = Target Index. "Integer"
*   Sends skill attack packet. "Void"
 
**GCSkillCancelSend(obj, skill)**
*   `obj` = User Object. "GameObject"
*   `skill` = Skill ID. "Integer"
*   Sends skill cancel packet. "Void"
 
**GCDurationSkillAttackSend(obj, targ, skill...)**
*   `obj` = User Object. "GameObject"
*   `targ` = Target. "Integer"
*   `skill` = Skill ID. "Integer"
*   Sends duration skill packet. "Void"
 
**GCSkillActionSend(obj, skill, targ...)**
*   `obj` = User Object. "GameObject"
*   `skill` = Skill ID. "Integer"
*   `targ` = Target Index. "Integer"
*   Sends skill action packet. "Void"
 
**GCRuneWizzardSkillAttackSend(obj, skill...)**
*   `obj` = User Object. "GameObject"
*   `skill` = Skill ID. "Integer"
*   Sends RW skill packet. "Void"
 
**GCRageFighterSkillAttackSend(obj, skill...)**
*   `obj` = User Object. "GameObject"
*   `skill` = Skill ID. "Integer"
*   Sends RF skill packet. "Void"
 
**GCSkillAddSend(index, slot, skill...)**
*   `index` = User Index. "Integer"
*   `slot` = Inv Slot. "Integer"
*   `skill` = Skill ID. "Integer"
*   Sends skill learn packet. "Void"
 
**GCSkillDelSend(index, slot, skill...)**
*   `index` = User Index. "Integer"
*   `slot` = Inv Slot. "Integer"
*   `skill` = Skill ID. "Integer"
*   Sends skill unlearn packet. "Void"
 
**GCSkillListSend(obj, type)**
*   `obj` = User Object. "GameObject"
*   `type` = 1 to send. "Integer"
*   Resends skill list. "Void"
 
**AddMasterSkill(obj, index, level)**
*   `obj` = User Object. "GameObject"
*   `index` = Skill ID. "Integer"
*   `level` = Skill Level. "Integer"
*   Adds Master Skill. "Integer"
 
**DelMasterSkill(obj, index)**
*   `obj` = User Object. "GameObject"
*   `index` = Skill ID. "Integer"
*   Removes Master Skill. "Integer"
 
**GetMasterSkill(obj, index)**
*   `obj` = User Object. "GameObject"
*   `index` = Skill ID. "Integer"
*   Returns Master Skill object. "CSkill*"
 
**GetMasterSkillValue(obj, skillIndex)**
*   `obj` = User Object. "GameObject"
*   `skillIndex` = Skill ID. "Integer"
*   Gets value from Master Tree. "Float"
 
**GetMasterSkillLevel(obj, skillIndex)**
*   `obj` = User Object. "GameObject"
*   `skillIndex` = Skill ID. "Integer"
*   Gets level from Master Tree. "Integer"
 
**CheckMasterLevel(obj)**
*   `obj` = User Object. "GameObject"
*   Checks if user is Master Level. "Boolean"
 
**AddEnhanceSkill(obj, idx, lvl, grp)**
*   `obj` = User Object. "GameObject"
*   `idx` = Skill ID. "Integer"
*   `lvl` = Skill Level. "Integer"
*   `grp` = Group. "Integer"
*   Adds Enhance Skill. "Integer"
 
**AddEnhancePassiveSkill(obj, idx, lvl, grp)**
*   `obj` = User Object. "GameObject"
*   `idx` = Skill ID. "Integer"
*   Adds Enhance Passive Skill. "Integer"
 
**GetEnhanceSkill(obj, index, grp)**
*   `obj` = User Object. "GameObject"
*   `index` = Skill ID. "Integer"
*   Gets Enhance Skill. "CSkill*"
 
**GetEnhancePassiveSkill(obj, index, grp)**
*   `obj` = User Object. "GameObject"
*   `index` = Skill ID. "Integer"
*   Gets Enhance Passive Skill. "CSkill*"
 
**GetEnhanceSkillValue(obj, idx, grp)**
*   `obj` = User Object. "GameObject"
*   `idx` = Skill ID. "Integer"
*   Gets Enhance Skill Value. "Integer"
 
**CheckEnhanceLevel(obj)**
*   `obj` = User Object. "GameObject"
*   Checks Enhance Level. "Boolean"
 
**SkillMagicGladiatorExplosion(obj, idx, dmg)**
*   `obj` = User Object. "GameObject"
*   `idx` = Target Index. "Integer"
*   `dmg` = Damage. "Integer"
*   MG Explosion logic. "Void"
 
 
### Effect Management
 
**AddEffect(obj, type, time, v1, v2, v3, v4)**
*   `obj` = User Object. "GameObject"
*   `type` = Effect ID. "Integer"
*   `time` = Duration (sec). "Integer"
*   `v1`...`v4` = Effect Values. "Integer"
*   Adds effect/buff. "Integer"
 
**DelEffect(obj, index)**
*   `obj` = User Object. "GameObject"
*   `index` = Effect ID. "Integer"
*   Deletes effect. "Boolean"
 
**DelEffectByGroup(obj, group)**
*   `obj` = User Object. "GameObject"
*   `group` = Effect Group. "Integer"
*   Deletes effect by group. "Boolean"
 
**CheckEffect(obj, index)**
*   `obj` = User Object. "GameObject"
*   `index` = Effect ID. "Integer"
*   Checks specific effect. "Boolean"
 
**CheckEffectByGroup(obj, group)**
*   `obj` = User Object. "GameObject"
*   `group` = Effect Group. "Integer"
*   Checks effect group. "Boolean"
 
**GetEffect(obj, index)**
*   `obj` = User Object. "GameObject"
*   `index` = Effect ID. "Integer"
*   Returns CEffect object. "CEffect*"
 
**GetEffectByGroup(obj, group)**
*   `obj` = User Object. "GameObject"
*   `group` = Effect Group. "Integer"
*   Returns CEffect by group. "CEffect*"
 
**GetMaxEffect()**
*   Returns constant: Max Effects. "Integer"
 
**ClearAllEffect(obj)**
*   `obj` = User Object. "GameObject"
*   Clears all effects. "Void"
 
**ClearDebuffEffect(obj)**
*   `obj` = User Object. "GameObject"
*   Clears all debuffs. "Void"
 
**CheckDebuffSend(obj, target)**
*   `obj` = User Object. "GameObject"
*   `target` = Target Object. "GameObject"
*   Checks if debuff can be sent. "Boolean"
 
**CheckStunEffect(obj)**
*   `obj` = User Object. "GameObject"
*   Checks if stunned. "Boolean"
 
**CheckImmobilizeEffect(obj)**
*   `obj` = User Object. "GameObject"
*   Checks if immobilized. "Boolean"
 
**UpgradeDamageByClass(atk, def, dmg, type)**
*   `atk` = Attacker. "GameObject"
*   `def` = Defender. "GameObject"
*   `dmg` = Damage. "Integer"
*   `type` = Type. "Integer"
*   Adjusts damage based on buffs. "Integer"
 
**GetFormulaSwordPowerMagicDamage(val)**
*   `val` = Input. "Integer"
*   Calculates Sword Power Magic Dmg. "Integer"
| `GetFormulaSwordPowerAttackSpeed` | `val` | `int` | Calculates Sword Power Atk Speed. |
| `GetFormulaSwordPowerDefenseRate` | `val` | `int` | Calculates Sword Power Def Rate. |
| `GetFormulaSwordPowerLifeReduction` | `val` | `int` | Calculates Sword Power Life Red. |
| `GetFormulaDarknessCurseDamage` | `val` | `int` | Calculates Darkness Curse Dmg. |
| `GetFormulaDarknessDefense` | `val` | `int` | Calculates Darkness Defense. |
| `GetFormulaDarknessLifeReduction` | `val` | `int` | Calculates Darkness Life Red. |
| `GetFormulaBatFlockDOTDamage` | `val` | `int` | Calculates Bat Flock DOT. |
 
### Party, Guild & Chat
 
**PartyCreate(index)**
*   `index` = User index. "Integer"
*   Return (1) if success, (0) otherwise.
 
**PartyDestroy(partyIndex)**
*   `partyIndex` = Party index. "Integer"
*   Return (1) if success, (0) otherwise.
 
**PartyAddMember(partyIndex, index)**
*   `partyIndex` = Party index. "Integer"
*   `index` = User index. "Integer"
*   Return (1) if success, (0) otherwise.
 
**PartyDelMember(partyIndex, index)**
*   `partyIndex` = Party index. "Integer"
*   `index` = User index. "Integer"
*   Return (1) if success, (0) otherwise.
 
**IsParty(obj)**
*   `obj` = User Object (`LPOBJ`). "GameObject"
*   Return (true) if user is in a party, (false) otherwise.
 
**GetMemberIndex(obj, n)**
*   `obj` = User Object (`LPOBJ`). "GameObject"
*   `n` = Member position index (0-4). "Integer"
*   Return User Index "Integer" of the member, or -1 if not found.
 
**GetPKPartyPenalty(obj)**
*   `obj` = User Object (`LPOBJ`). "GameObject"
*   Return PK Penalty level "Integer".
 
**gObjGetGuildUnionName(obj)**
*   `obj` = User Object (`LPOBJ`). "GameObject"
*   Return Guild Union Name "String".
 
**gObjGetGuildUnionNumber(obj)**
*   `obj` = User Object (`LPOBJ`). "GameObject"
*   Return Guild Union Number "Integer".
 
**gObjTargetGuildWarCheck(obj, target)**
*   `obj` = User Object (`LPOBJ`). "GameObject"
*   `target` = Target Object (`LPOBJ`). "GameObject"
*   Return (1) if at war, (0) otherwise.
 
**gObjGuildWarEnd(guild1, guild2)**
*   `guild1` = Guild Struct/ID. "Integer"
*   `guild2` = Guild Struct/ID. "Integer"
*   Ends the guild war. Return "Void".
 
**gObjGuildWarProc(obj)**
*   `obj` = User Object (`LPOBJ`). "GameObject"
*   Processes guild war state. Return "Void".
 
**gObjGuildWarCheck(obj, target)**
*   `obj` = User Object (`LPOBJ`). "GameObject"
*   `target` = Target Object (`LPOBJ`). "GameObject"
*   Checks guild war state. Return "Integer".
 
**gObjGuildWarMasterClose(obj)**
*   `obj` = User Object (`LPOBJ`). "GameObject"
*   Guild Master close handler. Return "Void".
 
**gObjGuildWarItemGive(obj, type)**
*   `obj` = User Object (`LPOBJ`). "GameObject"
*   `type` = Item type/flag. "Integer"
*   Gives Guild War item. Return "Void".
 
**gObjCheckRival(obj, target)**
*   `obj` = User Object (`LPOBJ`). "GameObject"
*   `target` = Target Object (`LPOBJ`). "GameObject"
*   Checks if target is a rival guild. Return (true/false).
 
**gObjGetRelationShip(obj, target)**
*   `obj` = User Object (`LPOBJ`). "GameObject"
*   `target` = Target Object (`LPOBJ`). "GameObject"
*   Returns relationship status (Ally/Rival). "Integer"
 
**gObjNotifyUpdateUnionV1(obj, target, type)**
*   `obj` = User Object. "GameObject"
*   `target` = Target User. "GameObject"
*   `type` = Update type. "Integer"
*   Updates union info V1. Return "Void".
 
**gObjNotifyUpdateUnionV2(obj, target, type)**
*   `obj` = User Object. "GameObject"
*   `target` = Target User. "GameObject"
*   `type` = Update type. "Integer"
*   Updates union info V2. Return "Void".
 
**gObjUnionUpdateProc(obj)**
*   `obj` = User Object (`LPOBJ`). "GameObject"
*   Processes union updates. Return "Void".
 
**PostSend(type, color, name, msg)**
*   `type` = Message type (usually 0). "Integer"
*   `color` = Color code (1=Blue, 2=Red, etc). "Integer"
*   `name` = Sender Name. "String"
*   `msg` = Message content. "String"
*   Sends a global post message. Return (true/false).
 
**GCChatTargetSend(obj, target, msg)**
*   `obj` = Sender Object. "GameObject"
*   `target` = Target Index/Object. "Integer"
*   `msg` = Message. "String"
*   Sends chat message to target. Return "Void".
 
**GCNoticeSend(index, type, msg)**
*   `index` = User Index. "Integer"
*   `type` = Notice Type (0:Center, 1:TopRight). "Integer"
*   `msg` = Message. "String"
*   Sends a notice message. Return "Void".
 
**GCNoticeSendToAll(type, msg)**
*   `type` = Notice Type. "Integer"
*   `msg` = Message. "String"
*   Sends notice to all players. "Void"
 
 
### Duel, PVP & Crywolf
 
**CheckDuel(obj, target)**
*   `obj` = User Object. "GameObject"
*   `target` = Target Object. "GameObject"
*   Checks if duel is possible. "Boolean"
 
**GetCrywolfState()**
*   Returns Crywolf event state. "Integer"
 
 
### Viewport & Networking
 
**gObjSetViewport(index, state)**
*   `index` = User Index. "Integer"
*   `state` = Viewport State. "Integer"
*   Sets viewport state. "Void"
 
**gObjViewportClose(obj)**
*   `obj` = User Object. "GameObject"
*   Closes viewport processing. "Void"
 
**gObjClearViewport(obj)**
*   `obj` = User Object. "GameObject"
*   Clears viewport. "Void"
 
**gObjClearViewportOfMine(obj)**
*   `obj` = User Object. "GameObject"
*   Clears self from others' viewports. "Void"
 
**gObjViewportListProtocolDestroy(obj)**
*   `obj` = User Object. "GameObject"
*   Destroys viewport protocol. "Void"
 
**gObjViewportListProtocolCreate(obj)**
*   `obj` = User Object. "GameObject"
*   Creates valid viewport list. "Void"
 
**gObjViewportListProtocol(obj)**
*   `obj` = User Object. "GameObject"
*   Processes viewport protocol. "Void"
 
**gObjViewportListDestroy(obj)**
*   `obj` = User Object. "GameObject"
*   Destroys viewport list. "Void"
 
**gObjViewportListCreate(obj)**
*   `obj` = User Object. "GameObject"
*   Creates viewport list. "Void"
 
**gObjViewportAttackAreaUsed(obj)**
*   `obj` = User Object. "GameObject"
*   Checks attack area usage. "Void"
 
**SendPacket(index, head, packet)**
*   `index` = User Index. "Integer"
*   `head` = Packet Header/ID. "Integer"
*   `packet` = Packet Object. "Packet"
*   Sends a custom `Packet` object to the user. "Void"
 
 
## Classes & Objects
 
### GameObject (User / Monster)
### GameObject (User / Monster)
Accessible via `GetUser(index)`. Use `obj.Property` to read/write.
 
**Index**
*   Object index. "Integer"
 
**AccountIndex**
*   Account index. "Integer"
 
**CharacterIndex**
*   Character index. "Integer"
 
**Connected**
*   Connection status (0=Empty, 1=Connected, 2=Playing). "Integer"
 
**LoginMessageSend**
*   Login message sent status. "Integer"
 
**LoginMessageCount**
*   Login message count. "Integer"
 
**CloseCount**
*   Connection close countdown. "Integer"
 
**CloseType**
*   Type of disconnection. "Integer"
 
**EnableDelCharacter**
*   Character deletion flag. "Integer"
 
**IpAddr**
*   IP Address. "String"
 
**DBNumber**
*   Database ID. "Integer"
 
**ClassCode**
*   Internal Class Code. "Integer"
 
**ClassFlag**
*   Class Flag. "Integer"
 
**CharacterCreationLevel**
*   Level at creation. "Integer"
 
**CharacterCreationLimitCount**
*   Creation limit count (Season 18). "Integer"
 
**AutoSaveTime**
*   Time since last autosave. "Integer"
 
**ConnectTickCount**
*   Tick count at connection time. "Integer"
 
**ClientTickCount**
*   Client-side tick count. "Integer"
 
**ServerTickCount**
*   Server-side tick count. "Integer"
 
**CheckTickCount**
*   Check tick count. "Integer"
 
**PostTime**
*   Last post time. "Integer"
 
**TimeCount**
*   Generic time counter. "Integer"
 
**PKTickCount**
*   PK timer. "Integer"
 
**CheckSumTableNum**
*   Checksum table index. "Integer"
 
**CheckSumTime**
*   Checksum time. "Integer"
 
**Type**
*   Object Type (1=User, 2=Monster, 3=NPC). "Integer"
 
**Live**
*   Alive status (1=Alive, 0=Dead). "Integer"
 
**Account**
*   Account ID. "String"
 
**Name**
*   Character Name. "String"
 
**PersonalCode**
*   Personal Code (ID). "String"
 
**Class**
*   Character Class (e.g., 0=DW, 1=DK). "Integer"
 
**DBClass**
*   Database Class ID. "Integer"
 
**ChangeUp**
*   Evolution level (0, 1, 2, 3). "Integer"
 
**Level**
*   Current Level. "Integer"
 
**LevelUpPoint**
*   Available stat points. "Integer"
 
**FruitAddPoint**
*   Points added by fruit. "Integer"
 
**FruitSubPoint**
*   Points removed by fruit. "Integer"
 
**Experience**
*   Current Experience. "Integer"
 
**NextExperience**
*   XP needed for next level. "Integer"
 
**Money**
*   Zen (Inventory). "Integer"
 
**RuudMoney**
*   Ruud amount. "Integer"
 
**Strength**
*   Strength stat. "Integer"
 
**Dexterity**
*   Dexterity stat. "Integer"
 
**Vitality**
*   Vitality stat. "Integer"
 
**Energy**
*   Energy stat. "Integer"
 
**Leadership**
*   Leadership stat (DL). "Integer"
 
**Life**
*   Current HP. "Float"
 
**MaxLife**
*   Maximum HP. "Float"
 
**ScriptMaxLife**
*   Scripted Max HP. "Float"
 
**Mana**
*   Current MP. "Float"
 
**MaxMana**
*   Maximum MP. "Float"
 
**ChatLimitTime**
*   Chat ban duration. "Integer"
 
**ChatLimitTimeSec**
*   Chat ban seconds. "Integer"
 
**ChatTicketCount**
*   Chat ticket. "Integer"
 
**AddStrength**
*   Added Strength. "Integer"
 
**AddDexterity**
*   Added Dexterity. "Integer"
 
**AddVitality**
*   Added Vitality. "Integer"
 
**AddEnergy**
*   Added Energy. "Integer"
 
**AddLeadership**
*   Added Leadership. "Integer"
 
**AddMasterStrength**
*   Master Tree Strength. "Integer"
 
**AddMasterDexterity**
*   Master Tree Dexterity. "Integer"
 
**AddMasterVitality**
*   Master Tree Vitality. "Integer"
 
**AddMasterEnergy**
*   Master Tree Energy. "Integer"
 
**AddMasterLeadership**
*   Master Tree Leadership. "Integer"
 
**BP**
*   Current AG (Stamina). "Integer"
 
**MaxBP**
*   Maximum AG. "Integer"
 
**AddBP**
*   Added AG. "Integer"
 
**VitalityToLife**
*   Converted Life from Vit. "Float"
 
**EnergyToMana**
*   Converted Mana from Ene. "Float"
 
**PKCount**
*   Kill count. "Integer"
 
**PKLevel**
*   PK Status (3=Common, 6=Phonomania). "Integer"
 
**PKTime**
*   PK reduction time. "Integer"
 
**X**
*   Current X coordinate. "Integer"
 
**Y**
*   Current Y coordinate. "Integer"
 
**Dir**
*   Facing direction. "Integer"
 
**Map**
*   Current Map Number. "Integer"
 
**AddLife**
*   Added Life. "Integer"
 
**AddMana**
*   Added Mana. "Integer"
 
**Shield**
*   Current SD. "Integer"
 
**MaxShield**
*   Maximum SD. "Integer"
 
**AddShield**
*   Added SD. "Integer"
 
**StartX**
*   Initial X. "Integer"
 
**StartY**
*   Initial Y. "Integer"
 
**OldX**
*   Previous X. "Integer"
 
**OldY**
*   Previous Y. "Integer"
 
**TX**
*   Target X. "Integer"
 
**TY**
*   Target Y. "Integer"
 
**MTX**
*   Move Target X. "Integer"
 
**MTY**
*   Move Target Y. "Integer"
 
**PathCount**
*   Movement path nodes count. "Integer"
 
**PathCur**
*   Current path index. "Integer"
 
**PathStartEnd**
*   Path start/end logic. "Integer"
 
**PathTime**
*   Movement time. "Integer"
 
**Authority**
*   Admin authority level. "Integer"
 
**AuthorityCode**
*   Admin code. "Integer"
 
**Penalty**
*   Game penalty. "Integer"
 
**AccountItemBlock**
*   Item block status. "Integer"
 
**ActionNumber**
*   Current action ID. "Integer"
 
**State**
*   Object state. "Integer"
 
**Rest**
*   Resting state. "Integer"
 
**ViewState**
*   Viewport state (e.g., invisible). "Integer"
 
**ViewSkillState**
*   Viewport skill state. "Integer"
 
**LastMoveTime**
*   Last movement tick. "Integer"
 
**LastAttackTime**
*   Last attack tick. "Integer"
 
**TeleportTime**
*   Last teleport tick. "Integer"
 
**Teleport**
*   Teleporting flag. "Integer"
 
**KillerType**
*   Type of entity that killed this obj. "Integer"
 
**DieRegen**
*   Regen after death flag. "Integer"
 
**RegenOk**
*   Regen ready flag. "Integer"
 
**RegenMapNumber**
*   Respawn Map. "Integer"
 
**RegenMapX**
*   Respawn X. "Integer"
 
**RegenMapY**
*   Respawn Y. "Integer"
 
**RegenTime**
*   Respawn timer. "Integer"
 
**MaxRegenTime**
*   Max respawn time. "Integer"
 
**PosNum**
*   Position number. "Integer"
 
**CurActionTime**
*   Current action duration. "Integer"
 
**NextActionTime**
*   Next action delay. "Integer"
 
**DelayActionTime**
*   Action delay. "Integer"
 
**DelayLevel**
*   Delay level. "Integer"
 
**DrinkSpeed**
*   Potion drink speed. "Integer"
 
**DrinkLastTime**
*   Last potion drink time. "Integer"
 
**MonsterDeleteTime**
*   Time until monster deletion. "Integer"
 
**KalimaGateExist**
*   Kalima gate status. "Integer"
 
**KalimaGateIndex**
*   Kalima gate index. "Integer"
 
**KalimaGateEnterCount**
*   Kalima gate entries. "Integer"
 
**AttackObj**
*   Object currently being attacked. "GAME_OBJECT"
 
**AttackerKilled**
*   Flag if attacker was killed. "Integer"
 
**MySelfDefenseTime**
*   Self-defense timer. "Integer"
 
**PartyNumber**
*   Party ID (-1 if none). "Integer"
 
**PartyTargetUser**
*   Targeted party member. "Integer"
 
**GuildNumber**
*   Guild ID. "Integer"
 
**GuildName**
*   Guild Name. "String"
 
**GuildStatus**
*   Guild Rank (128=GM, 64=Assist, etc). "Integer"
 
**GuildUnionTimeStamp**
*   Union join time. "Integer"
 
**SummonIndex**
*   Summoned Pet Index. "Integer"
 
**BuffField**
*   Buff field ID. "Integer"
 
**Change**
*   Skin ID (Monster ID). "Integer"
 
**TargetNumber**
*   Selected Target Index. "Integer"
 
**TargetPartyNumber**
*   Target Party ID. "Integer"
 
**TargetTradeNumber**
*   Target Trade ID. "Integer"
 
**TargetGuildNumber**
*   Target Guild ID. "Integer"
 
**TargetShopNumber**
*   Target Shop ID. "Integer"
 
**TargetNpcClass**
*   Target NPC Class. "Integer"
 
**ShopNumber**
*   Open Shop ID. "Integer"
 
**ShopTabIndex**
*   Shop tab. "Integer"
 
**LastAttackerID**
*   Index of last attacker. "Integer"
 
**MonsterStateTicket**
*   Monster AI State Ticket. "Integer"
 
**PhysiDamageMin**
*   Min Physical Damage. "Integer"
 
**PhysiDamageMax**
*   Max Physical Damage. "Integer"
 
**MagicDamageMin**
*   Min Magic Damage. "Integer"
 
**MagicDamageMax**
*   Max Magic Damage. "Integer"
 
**CurseDamageMin**
*   Min Curse Damage. "Integer"
 
**CurseDamageMax**
*   Max Curse Damage. "Integer"
 
**PhysiDamageMaxLeft**
*   Max Damage (Left Hand). "Integer"
 
**PhysiDamageMinLeft**
*   Min Damage (Left Hand). "Integer"
 
**PhysiDamageMaxRight**
*   Max Damage (Right Hand). "Integer"
 
**PhysiDamageMinRight**
*   Min Damage (Right Hand). "Integer"
 
**ExtraDamageMin**
*   Min Extra Damage. "Integer"
 
**ExtraDamageMax**
*   Max Extra Damage. "Integer"
 
**DKDamageMultiplierRate**
*   DK Damage % Multiplier. "Integer"
 
**DLDamageMultiplierRate**
*   DL Damage % Multiplier. "Integer"
 
**GLDamageChastisementRate**
*   GL Chastisement %. "Integer"
 
**GLDamageAttackRageRate**
*   GL Attack Rage %. "Integer"
 
**RWDamageMultiplierRate**
*   RW Damage % Multiplier. "Integer"
 
**SLDamageMultiplierRate**
*   SL Damage % Multiplier. "Integer"
 
**KMDamageMultiplierRate**
*   KM Damage % Multiplier. "Integer"
 
**LMDamageMultiplierRate**
*   LM Damage % Multiplier. "Integer"
 
**IKDamageMultiplierRate**
*   IK Damage % Multiplier. "Integer"
 
**ALDamageMultiplierRate**
*   AL Damage % Multiplier. "Integer"
 
**CSDamageMultiplierRate**
*   CS Damage % Multiplier. "Integer"
 
**AttackSuccessRate**
*   Hit Chance/Rate. "Integer"
 
**PhysiSpeed**
*   Attack speed (Phys). "Integer"
 
**MagicSpeed**
*   Attack speed (Magic). "Integer"
 
**Defense**
*   Defense. "Integer"
 
**MagicDefense**
*   Magic Defense. "Integer"
 
**DefenseSuccessRate**
*   Defense Rate (Evasion). "Integer"
 
**ElementalAttribute**
*   Element (1=Fire, 2=Water...). "Integer"
 
**ElementalPattern**
*   Element Pattern. "Integer"
 
**ElementalDefense**
*   Elemental Defense. "Integer"
 
**ElementalDamageMin**
*   Min Elemental Damage. "Integer"
 
**ElementalDamageMax**
*   Max Elemental Damage. "Integer"
 
**ElementalAttackSuccessRate**
*   Elemental Hit Rate. "Integer"
 
**ElementalDefenseSuccessRate**
*   Elemental Defense Rate. "Integer"
 
**ElementalBaseDefense**
*   Base Elemental Defense. "Integer"
 
**IsEliteMonster**
*   Elite flag. "Integer"
 
**MoveSpeed**
*   Movement Speed. "Integer"
 
**MoveRange**
*   Roaming Range (Monsters). "Integer"
 
**AttackRange**
*   Attack Range. "Integer"
 
**AttackType**
*   Attack Type (Range/Melee). "Integer"
 
**ViewRange**
*   Range of sight. "Integer"
 
**Attribute**
*   Monster Attribute. "Integer"
 
**ItemRate**
*   Drop rate multiplier. "Integer"
 
**MoneyRate**
*   Money drop rate multiplier. "Integer"
 
**MultiSkillIndex**
*   Current MultiSkill Index. "Integer"
 
**MultiSkillCount**
*   MultiSkill counter. "Integer"
 
**RageFighterSkillIndex**
*   RF Skill Index. "Integer"
 
**ProtectionHitCount**
*   Protection hit count. "Integer"
 
**RageFighterSkillCount**
*   RF Skill Count. "Integer"
 
**RageFighterSkillTarget**
*   RF Skill Target. "Integer"
 
**onRageFighterSkillTarget**
*   RF Skill Target flag. "Integer"
 
**RageFighterSkill**
*   RF Skill ID. "Integer"
 
**IsRageFigtherBlockSkill**
*   RF Block Skill flag. "Integer"
 
**VPCount**
*   Viewport Player Count. "Integer"
 
**VPCount2**
*   Viewport Player Count (Type 2). "Integer"
 
**VPCountItem**
*   Viewport Item Count. "Integer"
 
**HitDamageCount**
*   Hit count. "Integer"
 
**InterfaceTime**
*   Interface open time. "Integer"
 
**Transaction**
*   Transaction mode (1=Trade). "Integer"
 
**TransactionType**
*   Transaction type. "Integer"
 
**loadCharacterItemList**
*   Loading items flag. "Integer"
 
**TradeMoney**
*   Zen in Trade. "Integer"
 
**TradeOk**
*   Trade Confirmed flag. "Integer"
 
**WarehouseCount**
*   Warehouse open count. "Integer"
**WarehousePW**
*   Warehouse Password set. "Integer"
 
**WarehouseLock**
*   Warehouse Locked. "Integer"
 
**WarehouseMoney**
*   Zen in Warehouse. "Integer"
 
**WarehouseSave**
*   Warehouse Saved flag. "Integer"
 
**ChaosMoney**
*   Zen in Chaos Machine. "Integer"
 
**ChaosSuccessRate**
*   Chaos Mix Rate. "Integer"
 
**ChaosLock**
*   Chaos Machine Locked. "Integer"
 
**ChaosMassMixSuccessCount**
*   Mass Mix Successes. "Integer"
 
**LoadEventInventory**
*   Event Inv Loaded. "Integer"
 
**LoadMuunInventory**
*   Muun Inv Loaded. "Integer"
 
**MuunRide**
*   Muun Ride Active. "Integer"
 
**PetItemSwitch**
*   Active Pet Slot. "Integer"
 
**MuunViewSlot**
*   Visible Muun Slot. "Integer"
 
**DarkSpiritPos**
*   Dark Spirit inventory slot. "Integer"
 
**EquipamentFlagSlot**
*   Equip flag. "Integer"
 
**Option**
*   General Option flags. "Integer"
 
**ChaosCastleBlowTime**
*   CC Blow time. "Integer"
 
**DuelUserReserved**
*   Duel Reserved user. "Integer"
 
**DuelUserRequested**
*   Duel Request user. "Integer"
 
**DuelUser**
*   Duel Opponent index. "Integer"
 
**DuelScore**
*   Current Duel Score. "Integer"
 
**DuelTickCount**
*   Duel Tick. "Integer"
 
**PShopOpen**
*   Personal Shop Open. "Integer"
 
**PShopTransaction**
*   PShop Transaction active. "Integer"
 
**PShopItemChange**
*   PShop Item Changed. "Integer"
 
**PShopRedrawAbs**
*   PShop Redraw required. "Integer"
 
**PShopText**
*   Shop Title. "String"
 
**PShopWantDeal**
*   PShop Deal mode. "Integer"
 
**PShopDealerIndex**
*   Dealer Index. "Integer"
 
**PShopDealerName**
*   Dealer Name. "String"
 
**PShopCustom**
*   Custom Shop active. "Integer"
 
**PShopCustomType**
*   Custom Shop Type. "Integer"
 
**PShopCustomReqBuyTicket**
*   Buy Ticket Req. "Integer"
 
**PShopOnBuyProc**
*   Buy Processing flag. "Integer"
 
**PShopCustomOffline**
*   Offline Shop active. "Integer"
 
**PShopCustomOfflineTime**
*   Offline Shop time. "Integer"
 
**PShopCustomSellTimeDisconect**
*   Disconnect time. "Integer"
 
**VpPShopPlayerCount**
*   Viewport Shop Count. "Integer"
 
**IsInBattleGround**
*   Battleground flag. "Integer"
 
**HaveWeaponInHand**
*   Weapon equipped. "Integer"
 
**UseEventServer**
*   Event Server mode. "Integer"
 
**EventChipCount**
*   Renaissance Chip count. "Integer"
 
**MutoNumber**
*   Muto monster number. "Integer"
 
**LoadWarehouse**
*   Warehouse Loaded. "Integer"
 
**SendQuestInfo**
*   Send Quest Info flag. "Integer"
 
**CheckLifeTime**
*   Life regen check time. "Integer"
 
**LastTeleportTime**
*   Last teleport time. "Integer"
 
**SkillNovaState**
*   Nova skill state. "Integer"
 
**SkillNovaCount**
*   Nova skill count. "Integer"
 
**SkillNovaTime**
*   Nova skill time. "Integer"
 
**ReqWarehouseOpen**
*   Open Warehouse Request. "Integer"
 
**IsFullSetItem**
*   Ancient Set Active. "Integer"
 
**SkillSummonPartyTime**
*   Summon Party cooldown. "Integer"
 
**SkillSummonPartyMap**
*   Summon Party Map. "Integer"
 
**SkillSummonPartyX**
*   Summon Party X. "Integer"
 
**SkillSummonPartyY**
*   Summon Party Y. "Integer"
 
**IsChaosMixCompleted**
*   Mix Complete flag. "Integer"
 
**SkillLongSpearChange**
*   DL Spear stance. "Integer"
 
**CharSaveTime**
*   Character Save time. "Integer"
 
**LoadQuestKillCount**
*   Quest Kill Count loaded. "Integer"
 
**QuestKillCountIndex**
*   Quest Kill Index. "Integer"
 
**QuestItemDropIndex**
*   Quest Drop Index. "Integer"
 
**QuestItemDropTicket**
*   Quest Drop Ticket. "Integer"
 
**LoadMasterLevel**
*   Master Level Loaded. "Integer"
 
**MasterLevel**
*   Current Master Level. "Integer"
 
**MasterPoint**
*   Master Points available. "Integer"
 
**MasterExperience**
*   Master Experience. "Integer"
 
**MasterNextExperience**
*   Next Master Exp. "Integer"
 
**ExtInventory**
*   Ext Inventory active. "Integer"
 
**ExtWarehouse**
*   Ext Warehouse active. "Integer"
 
**WarehouseNumber**
*   Warehouse Index. "Integer"
 
**AccountLevel**
*   VIP Level. "Integer"
 
**AccountExpireDate**
*   VIP Expiration Date. "String"
 
**AccountExpireTime**
*   VIP Expiration Time. "Integer"
 
**AccountExpireSend**
*   VIP Expiration Sent. "Integer"
 
**LevelAccountTickCount**
*   VIP Tick. "Integer"
 
**AutoPartyPassword**
*   Auto Party Pwd. "String"
 
**AutoAddPointCount**
*   Auto Points to add. "Integer"
 
**AutoResetEnable**
*   Auto Reset Active. "Integer"
 
**MiniMapState**
*   Minimap State. "Integer"
 
**MiniMapValue**
*   Minimap Value. "Integer"
 
**MiningStage**
*   Mining stage. "Integer"
 
**MiningIndex**
*   Mining index. "Integer"
 
**UseGuildMatching**
*   Guild Matching active. "Integer"
 
**UseGuildMatchingJoin**
*   Guild Matching Join. "Integer"
 
**UsePartyMatching**
*   Party Matching active. "Integer"
 
**UsePartyMatchingJoin**
*   Party Matching Join. "Integer"
 
**UsePartyMatchingAutoMove**
*   Party Match Automove. "Integer"
 
**PartyMatchingLeader**
*   Party Leader. "Integer"
 
**PartyMatchingIndex**
*   Party Match Index. "Integer"
 
**PartyMatchingMemberCount**
*   Member count. "Integer"
 
**SendDeletePartyMember**
*   Delete Member flag. "Integer"
 
**AutoAttackTime**
*   Auto Attack timer. "Integer"
 
**TradeOkTime**
*   Trade Confirmation timer. "Integer"
 
**PotionTime**
*   Potion timer. "Integer"
 
**ComboTime**
*   BK Combo timer. "Integer"
 
**HelperDelayTime**
*   MU Helper delay. "Integer"
 
**HelperTotalTime**
*   MU Helper duration. "Integer"
 
**HelperState**
*   MU Helper Active. "Integer"
 
**LabyrinthHelperTime**
*   Labyrinth timer. "Integer"
 
**CustomAttackState**
*   /attack active. "Integer"
 
**CustomAttackSkill**
*   /attack skill ID. "Integer"
 
**CustomAttackTickCount**
*   /attack timer. "Integer"
 
**CustomAttackMoneyTickCount**
*   /attack money timer. "Integer"
 
**CustomAttackOnPath**
*   /attack walking. "Integer"
 
**CustomAttackPathCount**
*   /attack path index. "Integer"
 
**CustomAttackPathInitialCount**
*   /attack start path. "Integer"
 
**DisconectCount**
*   Disconnection counter. "Integer"
 
**CustomAttackMapActive**
*   /attack map active. "Integer"
 
**CustomAttackMapViewRange**
*   /attack view range. "Integer"
 
**AttackCustomOfflineDelay**
*   OffAttack delay. "Integer"
 
**AttackCustomOfflineZoneX**
*   OffAttack X. "Integer"
 
**AttackCustomOfflineZoneY**
*   OffAttack Y. "Integer"
 
**AttackCustomZoneMap**
*   OffAttack Map. "Integer"
 
**OnReconnectionOffAttack**
*   OffAttack Reconnect. "Integer"
 
**AttackCustomOffline**
*   OffAttack Active. "Integer"
 
**AttackCustomOfflineTime**
*   OffAttack Time. "Integer"
 
**AttackCustomActiveTicketCount**
*   OffAttack Ticket. "Integer"
 
**OffattackActiveInSecureZoneTicketCount**
*   SafeZone Ticket. "Integer"
 
**AttackCustomOfflineMoneyDelay**
*   Money Pickup Delay. "Integer"
 
**AttackCustomOfflinePotDelay**
*   Potion Check Delay. "Integer"
 
**AttackCustomDontMoveSummonReq**
*   Summon Req Lock. "Integer"
 
**AttackCustomRepairTicketCount**
*   Repair Ticket. "Integer"
 
**PcPointPointTime**
*   PC Point timer. "Integer"
 
**HPAutoRecuperationTime**
*   HP Regen timer. "Integer"
 
**MPAutoRecuperationTime**
*   MP Regen timer. "Integer"
 
**BPAutoRecuperationTime**
*   BP Regen timer. "Integer"
 
**SDAutoRecuperationTime**
*   SD Regen timer. "Integer"
 
**CashShopGoblinPointTime**
*   Goblin Point timer. "Integer"
 
**Reset**
*   Reset Count. "Integer"
 
**MasterReset**
*   Master Reset Count. "Integer"
 
**EnhanceReset**
*   Enhance Reset Count. "Integer"
 
**ChangeSkin**
*   Skin ID. "Integer"
 
**LoadQuestWorld**
*   Quest World Loaded. "Integer"
 
**QuestWorldMonsterClass**
*   Quest Monster Class. "Integer"
 
**m_bDBQuestLoad**
*   DB Quest Loaded. "Integer"
 
**DBQuestGuideLoad**
*   Quest Guide Loaded. "Integer"
 
**DBMuQuestLoad**
*   MuQuest Loaded. "Integer"
 
**LoadGens**
*   Gens Loaded. "Integer"
 
**GensFamily**
*   Gens Family (1=D, 2=V). "Integer"
 
**GensRank**
*   Gens Rank. "Integer"
 
**GensSymbol**
*   Gens Symbol. "Integer"
 
**GensContribution**
*   Gens Points. "Integer"
 
**GensNextContribution**
*   Gens Next Points. "Integer"
 
**ChaosCastleInterfaceState**
*   CC UI State. "Integer"
 
**EffectOption**
*   Active Effect Options. "Integer"
 
**ArmorSetBonus**
*   Set Bonus Active. "Integer"
 
**SkillDamageBonus**
*   Skill Dmg Bonus. "Integer"
 
**DoubleDamageRate**
*   Double Dmg %. "Integer"
 
**TripleDamageRate**
*   Triple Dmg %. "Integer"
 
**IgnoreDefenseRate**
*   Ignore Def %. "Integer"
 
**IgnoreShieldGaugeRate**
*   Ignore SD %. "Integer"
 
**CriticalDamageRate**
*   Crit Rate %. "Integer"
 
**CriticalDamage**
*   Crit Dmg. "Integer"
 
**ExcellentDamageRate**
*   Exc Rate %. "Integer"
 
**ExcellentDamage**
*   Exc Dmg. "Integer"
 
**ResistDoubleDamageRate**
*   Resist Double %. "Integer"
 
**ResistIgnoreDefenseRate**
*   Resist Ignore Def %. "Integer"
 
**ResistIgnoreShieldGaugeRate**
*   Resist Ignore SD %. "Integer"
 
**ResistCriticalDamageRate**
*   Resist Crit %. "Integer"
 
**ResistExcellentDamageRate**
*   Resist Exc %. "Integer"
 
**ResistStunRate**
*   Resist Stun %. "Integer"
 
**ResistDebuffRate**
*   Resist Debuff %. "Integer"
 
**ExperienceRate**
*   Exp Rate %. "Integer"
 
**MasterExperienceRate**
*   Master Exp Rate %. "Integer"
 
**ItemDropRate**
*   Drop Rate %. "Integer"
 
**MoneyAmountDropRate**
*   Zen Drop Rate %. "Integer"
 
**HPRecovery**
*   HP Recovery amount. "Integer"
 
**MPRecovery**
*   MP Recovery amount. "Integer"
 
**BPRecovery**
*   BP Recovery amount. "Integer"
 
**SDRecovery**
*   SD Recovery amount. "Integer"
 
**HPRecoveryRate**
*   HP Recovery %. "Integer"
 
**MPRecoveryRate**
*   MP Recovery %. "Integer"
 
**BPRecoveryRate**
*   BP Recovery %. "Integer"
 
**SDRecoveryRate**
*   SD Recovery %. "Integer"
 
**SDRecoverySpeedRate**
*   SD Rec. Speed %. "Integer"
 
**SDRecoveryType**
*   SD Rec. Type. "Integer"
 
**HPRecoveryCount**
*   HP Rec. Counter. "Integer"
 
**MPRecoveryCount**
*   MP Rec. Counter. "Integer"
 
**BPRecoveryCount**
*   BP Rec. Counter. "Integer"
 
**SDRecoveryCount**
*   SD Rec. Counter. "Integer"
 
**MPConsumptionRate**
*   Mana Cost %. "Integer"
 
**BPConsumptionRate**
*   AG Cost %. "Integer"
 
**ShieldGaugeRate**
*   Shield Rate %. "Integer"
 
**DecreaseShieldGaugeRate**
*   Decr. Shield %. "Integer"
 
**DamagePvP**
*   PVP Dmg Bonus. "Integer"
 
**DefensePvP**
*   PVP Def Bonus. "Integer"
 
**AttackSuccessRatePvP**
*   PVP Hit Rate. "Integer"
 
**DefenseSuccessRatePvP**
*   PVP Def Rate. "Integer"
 
**ShieldDamageReduction**
*   SD Dmg Reduc. "Integer"
 
**ShieldDamageReductionTime**
*   SD Reduc Time. "Integer"
 
**DamageReduction**
*   Damage Reduction. "Integer"
 
**MonsterDamageReduction**
*   PVM Dmg Reduction. "Integer"
 
**DamageReflect**
*   Dmg Reflect %. "Integer"
 
**CombatPowerRate**
*   Combat Power %. "Integer"
 
**CombatPowerFormulaType**
*   CP Formula. "Integer"
 
**HuntHP**
*   Hunt HP Bonus. "Integer"
 
**HuntMP**
*   Hunt MP Bonus. "Integer"
 
**HuntBP**
*   Hunt BP Bonus. "Integer"
 
**HuntSD**
*   Hunt SD Bonus. "Integer"
 
**WeaponDurabilityRate**
*   Weapon Dur % Loss. "Integer"
 
**ArmorDurabilityRate**
*   Armor Dur % Loss. "Integer"
 
**WingDurabilityRate**
*   Wing Dur % Loss. "Integer"
 
**GuardianDurabilityRate**
*   Guardian Dur % Loss. "Integer"
 
**PendantDurabilityRate**
*   Pendant Dur % Loss. "Integer"
 
**RingDurabilityRate**
*   Ring Dur % Loss. "Integer"
 
**PetDurabilityRate**
*   Pet Dur % Loss. "Integer"
 
**FullDamageReflectRate**
*   Full Reflect %. "Integer"
 
**DefensiveFullHPRestoreRate**
*   Def Full HP Restore %. "Integer"
 
**DefensiveFullMPRestoreRate**
*   Def Full MP Restore %. "Integer"
 
**DefensiveFullSDRestoreRate**
*   Def Full SD Restore %. "Integer"
 
**DefensiveFullBPRestoreRate**
*   Def Full BP Restore %. "Integer"
 
**OffensiveFullHPRestoreRate**
*   Off Full HP Restore %. "Integer"
 
**OffensiveFullMPRestoreRate**
*   Off Full MP Restore %. "Integer"
 
**OffensiveFullSDRestoreRate**
*   Off Full SD Restore %. "Integer"
 
**OffensiveFullBPRestoreRate**
*   Off Full BP Restore %. "Integer"
 
**BlockWeaponRate**
*   Block Weapon %. "Integer"
 
**BlockShieldRate**
*   Block Shield %. "Integer"
 
**ProtectionShieldRate**
*   Protection Shield %. "Integer"
 
**ImproveSheldDefence**
*   Improved SD Def. "Integer"
 
**BaseDefense**
*   Base Defense. "Integer"
 
**AbsorbHP**
*   HP Absorb %. "Integer"
 
**AbsorbSD**
*   SD Absorb %. "Integer"
 
**DamageRange**
*   Damage Range. "Integer"
 
**DamageMelee**
*   Melee Damage. "Integer"
 
**ResurrectionTalismanActive**
*   Talisman Active. "Integer"
 
**ResurrectionTalismanMap**
*   Talisman Map. "Integer"
 
**ResurrectionTalismanX**
*   Talisman X. "Integer"
 
**ResurrectionTalismanY**
*   Talisman Y. "Integer"
 
**MobilityTalismanActive**
*   Mobility Talisman. "Integer"
 
**MobilityTalismanMap**
*   Mob. Talisman Map. "Integer"
 
**MobilityTalismanX**
*   Mob. Talisman X. "Integer"
 
**MobilityTalismanY**
*   Mob. Talisman Y. "Integer"
 
**MapServerMoveQuit**
*   Server move quit flag. "Integer"
 
**MapServerMoveRequest**
*   Server move req flag. "Integer"
 
**MapServerMoveQuitTickCount**
*   Server move timer. "Integer"
 
**NextServerCode**
*   Dest Server ID. "Integer"
 
**LastServerCode**
*   Source Server ID. "Integer"
 
**DestMap**
*   Dest. Map. "Integer"
 
**DestX**
*   Dest. X. "Integer"
 
**DestY**
*   Dest. Y. "Integer"
 
**CsNpcType**
*   Castle Siege NPC Type. "Integer"
 
**CsGateOpen**
*   Gate Open Flag. "Integer"
 
**CsGateLeverLinkIndex**
*   Gate Lever ID. "Integer"
 
**CsNpcDfLevel**
*   NPC Def Level. "Integer"
 
**CsNpcRgLevel**
*   NPC Regen Level. "Integer"
 
**CsJoinSide**
*   Siege Side (1=Att, 2=Def). "Integer"
 
**CsGuildInvolved**
*   Siege Guild Flag. "Integer"
 
**IsCastleNPCUpgradeCompleted**
*   Upgrade Done. "Integer"
 
**CsSiegeWeaponState**
*   Weapon State. "Integer"
 
**CsWeaponIndex**
*   Weapon Index. "Integer"
 
**KillCount**
*   CS Kill Count. "Integer"
 
**AccumulatedDamage**
*   CS Dmg Accum. "Integer"
 
**LifeStoneCount**
*   Life Stone count. "Integer"
 
**CreationState**
*   Creation state. "Integer"
 
**CreatedActivationTime**
*   Creation time. "Integer"
 
**AccumulatedCrownAccessTime**
*   Crown Access Time. "Integer"
 
**BasicAI**
*   AI Type. "Integer"
 
**CurrentAI**
*   Active AI. "Integer"
 
**CurrentAIState**
*   AI State. "Integer"
 
**LastAIRunTime**
*   AI Tick. "Integer"
 
**GroupNumber**
*   Group ID. "Integer"
 
**SubGroupNumber**
*   SubGroup ID. "Integer"
 
**GroupMemberGuid**
*   Member GUID. "Integer"
 
**RegenType**
*   Regen Type. "Integer"
 
**LastAutomataRuntime**
*   Automata Tick. "Integer"
 
**LastAutomataDelay**
*   Automata Delay. "Integer"
 
**CrywolfMVPScore**
*   Crywolf Score. "Integer"
 
**LastCheckTick**
*   Last Check. "Integer"
 
**LanguageType**
*   Language ID. "Integer"
 
**GiftNewbiesStatus**
*   Welcome Gift Flag. "Integer"
 
**HardwareId**
*   HWID. "String"
 
**HardwareIdStatus**
*   HWID Verified. "Integer"
 
**AllowCheckTick**
*   Check Tick. "Integer"
 
**HardwareIdTicket**
*   HWID Ticket. "Integer"
 
**BlockMuWebAdsTime**
*   Ads block time. "Integer"
 
**MuWebAdsStatus**
*   Ads status. "Integer"
 
**MuWebAdsViewTicket**
*   Ads ticket. "Integer"
 
**MuWebAdsOnView**
*   Ads viewing. "Integer"
 
**MuWebAdsViewID**
*   Ads ID. "Integer"
 
**BlockMuWebAdsOnViewTime**
*   Ads view time. "Integer"
 
**BotType**
*   Bot Type. "Integer"
 
**BotStoreDelItem**
*   Bot Del Item. "Integer"
 
**AllowCreateGuild**
*   Guild Create Allow. "Integer"

---

## Usage Examples

### 1. Global Utility
```lua
function Example_Utility()
    -- Log a message in Red color
    LogAdd(2, "Hello from Lua!")
    
    -- Get current server uptime
    local tick = GetTickCount() 
    LogAdd(3, string.format("Server Uptime: %d", tick))
    
    -- Generate random number 0-99
    local rnd = rand(100)
    
    -- Calculate distance between two points
    local dist = gObjCalcDistance(150, 150, 160, 160)
end
```

### 2. User Management
```lua
function Example_User(aIndex)
    -- Get user object
    local player = GetUser(aIndex)
    
    if player == nil then return end

    -- Check if connected and is a player (Type 1)
    if player.Connected == 2 and player.Type == 1 then
        -- Modify stats
        player.Money = player.Money + 1000
        player.LevelUpPoint = player.LevelUpPoint + 5
        
        -- Send notification (Type 0 = Center)
        GCNoticeSend(aIndex, 0, "You received 1000 Zen and 5 Points!")
        
        -- Send update packet to client
        gObjCharacterSetZen(player, player.Money)
    end
    
    -- Teleport user
    gObjTeleport(aIndex, 0, 125, 125) -- Lorencia
end
```

### 3. Item Management
```lua
function Example_Item(aIndex)
    -- Give a Kris+15+Luck+Skill+Exc
    -- ItemGiveEx(index, id, lvl, dur, skil, luck, opt, newOpt, set, joh, exc, s1, s2, s3, s4, s5, bonus, time)
    ItemGiveEx(aIndex, GET_ITEM(0, 0), 15, 255, 1, 1, 1, 63, 0, 0, 0, 255, 255, 255, 255, 255, 0, 0)
    
    -- Drop a Jewel of Bless at player's feet
    local p = GetUser(aIndex)
    ItemDrop(aIndex, p.Map, p.X, p.Y, GET_ITEM(14, 13))
    
    -- Check inventory space (2x3 cells for a weapon)
    if InventoryCheckSpaceBySize(aIndex, 2, 3) then
        LogAdd(3, "Player has space.")
    end
end
```

### 4. Monster Management
```lua
function BridgeFunction_OnMonsterDie(monsterIndex, killerIndex)
    local monster = GetUser(monsterIndex)
    local killer = GetUser(killerIndex)
    
    -- Check if killer is a player
    if killer.Type == 1 then
        GCNoticeSend(killer.Index, 1, "You killed a monster!")
        
        -- If monster was a Bull Fighter (Class 4)
        if monster.Class == 4 then
             MoneyDrop(killer.Index, killer.Map, killer.X, killer.Y, 10000)
        end
    end
    
    return 0
end
```

### 5. Event Hooks
```lua
function BridgeFunction_OnCharacterEntry(aIndex)
    local player = GetUser(aIndex)
    
    -- Welcome message
    GCNoticeSend(aIndex, 1, string.format("Welcome %s!", player.Name))
    
    -- Reset check
    if player.Reset > 10 then
        -- Give special buff
        AddEffect(player, 1, 0, 3600, 0, 0, 0) -- Example effect
    end
end

function BridgeFunction_OnCommandManager(aIndex, code, arg)
    -- /test command
    if code == 1 then -- mapped to /test in server settings
        local player = GetUser(aIndex)
        GCNoticeSend(aIndex, 1, "Test command executed via Lua!")
        return 1 -- Consume command
    end
    return 0 -- Continue processing
end
```

### 6. Effect Management
```lua
function Example_Buff(aIndex)
    local player = GetUser(aIndex)
    
    -- Check if player already has "Greater Defense" (Effect ID 2)
    if CheckEffect(player, 2) == false then
        -- Add Greater Defense (Index 2)
        -- Time: 60 seconds
        -- V1: 50 (Defense Power)
        -- V2: 0, V3: 0, V4: 0
        AddEffect(player, 2, 60, 50, 0, 0, 0)
        
        GCNoticeSend(aIndex, 1, "Greater Defense Buff applied!")
    else
        -- Remove the effect
        DelEffect(player, 2)
        GCNoticeSend(aIndex, 1, "Buff Update.")
    end
end
```

### 7. Packet & Networking
```lua
-- Respond to a custom packet
function BridgeFunction_OnPacketRecv(aIndex, head, packet)
    -- Suppose clients send packet with Header 0x1234
    if head == 0x1234 then
        local subCode = packet:ReadByte()
        local msg = packet:ReadString()
        
        LogAdd(3, string.format("Recv Packet: Sub=%d, Msg=%s", subCode, msg))
        
        -- Send a response
        local p = Packet()
        p:WriteByte(0x01) -- Success
        p:WriteString("Received OK")
        
        -- SendPacket(index, header, packet)
        SendPacket(aIndex, 0x5678, p) 
        
        return 1 -- Handled
    end
    return 0
end
```


### GameItem
Represents an item in an inventory/slot.
 
**m_Index**
*   Item ID. "Integer"
 
**m_Level**
*   Item Level (+0 to +15). "Integer"
 
**m_Durability**
*   Current durability. "Float"
 
**m_Option1**
*   Skill Option. "Integer"
 
**m_Option2**
*   Luck Option. "Integer"
 
**m_Option3**
*   Life Option. "Integer"
 
**m_NewOption**
*   Excellent Option bits. "Integer"
 
**m_SetOption**
*   Ancient Set ID. "Integer"
 
**m_JewelOfHarmonyOption**
*   JoH Option. "Integer"
 
**m_SocketOption**
*   Socket information (Array). "Table"
 
**m_Serial**
*   Unique Item Serial. "Integer"
 
**Methods**
*   `IsItem()`: Checks if item exists.
*   `IsExcItem()`: Checks if item is Excellent.
*   `IsSetItem()`: Checks if item is Ancient.
*   `IsWingItem()`: Checks if item is a Wing.
*   `IsPentagramItem()`: Checks if item is a Pentagram.
*   `GetName()`: Returns item name.
*   `GetDamageMin()`: Returns min damage.
*   `GetDefense()`: Returns defense.
 
### Packet
Used to construct network packets for `SendPacket`.
 
**Packet()**
*   Constructor. Creates a new packet object.
 
**WriteByte(value)**
*   Writes a byte to the packet. "Integer"
 
**WriteWord(value)**
*   Writes a word (2 bytes) to the packet. "Integer"
 
**WriteDword(value)**
*   Writes a dword (4 bytes) to the packet. "Integer"
 
**WriteString(value)**
*   Writes a string to the packet. "String"
 
**ReadByte()**
*   Reads a byte from the packet (use in Receive Hook). "Integer"
 
**ReadWord()**
*   Reads a word (2 bytes) from the packet. "Integer"
 
**ReadDword()**
*   Reads a dword (4 bytes) from the packet. "Integer"
 
**ReadString()**
*   Reads a string from the packet. "String"
 
---
 
## Event Hooks (Callbacks)
Implement these functions in your Lua script to handle server events.
 
**BridgeFunction_OnTimerThread()**
*   Called on server tick loop. 
*   Return: None
 
**BridgeFunction_OnShutScript()**
*   Called when reloading scripts.
*   Return: None
 
**BridgeFunction_OnReadScript()**
*   Called when loading scripts.
*   Return: None
 
**BridgeFunction_OnConnectDataBase()**
*   Called after DB Connect.
*   Return: None
 
**BridgeFunction_OnCommandManager(index, code, arg)**
*   `index`: User Index. "Integer"
*   `code`: Command Code. "Integer"
*   `arg`: Command Arguments. "String"
*   Return: 1 to block command, 0 to process.
 
**BridgeFunction_OnCharacterEntry(index)**
*   `index`: User Index. "Integer"
*   Called when player enters game.
*   Return: None
 
**BridgeFunction_OnCharacterClose(index)**
*   `index`: User Index. "Integer"
*   Called when player leaves.
*   Return: None
 
**BridgeFunction_OnNpcTalk(index, npcIndex)**
*   `index`: User Index. "Integer"
*   `npcIndex`: NPC Object Index. "Integer"
*   Called when clicking NPC.
*   Return: None
 
**BridgeFunction_OnMonsterDie(killerIndex, monsterIndex)**
*   `killerIndex`: Killer Index. "Integer"
*   `monsterIndex`: Victim Monster Index. "Integer"
*   Called when monster dies.
*   Return: None
 
**BridgeFunction_OnUserDie(victimIndex, killerIndex)**
*   `victimIndex`: Victim User Index. "Integer"
*   `killerIndex`: Killer Index. "Integer"
*   Called when user dies.
*   Return: None
 
**BridgeFunction_OnUserRespawn(index, killType)**
*   `index`: User Index. "Integer"
*   `killType`: Type of death. "Integer"
*   Called on respawn.
*   Return: None
 
**BridgeFunction_OnCheckUserTarget(index, targetIndex)**
*   `index`: User Index. "Integer"
*   `targetIndex`: Target Index. "Integer"
*   Validate PVP target.
*   Return: None
 
**BridgeFunction_OnItemGet(index, itemIndex, itemObj)**
*   `index`: User Index. "Integer"
*   `itemIndex`: Item Index (in world). "Integer"
*   `itemObj`: GameItem Object. "GameItem"
*   Called on pick up.
*   Return: None
 
**BridgeFunction_OnItemDrop(index, slot, x, y, itemObj)**
*   `index`: User Index. "Integer"
*   `slot`: Inventory Slot. "Integer"
*   `x`: Map X. "Integer"
*   `y`: Map Y. "Integer"
*   `itemObj`: GameItem Object. "GameItem"
*   Called on drop.
*   Return: None
 
**BridgeFunction_OnPacketRecv(index, header, packetObj)**
*   `index`: User Index. "Integer"
*   `header`: Packet Header ID. "Integer"
*   `packetObj`: Packet Object. "Packet"
*   Called on packet receive.
*   Return: 1 to consume packet, 0 to process normally.
 
**BridgeFunction_OnMapChange(index, oldMap, newMap)**
*   `index`: User Index. "Integer"
*   `oldMap`: Previous Map Number. "Integer"
*   `newMap`: New Map Number. "Integer"
*   Called on map move.
*   Return: None
 
**BridgeFunction_OnTradeStart(index, targetIndex)**
*   `index`: User Index. "Integer"
*   `targetIndex`: Target User Index. "Integer"
*   Called on Trade Request.
*   Return: None
 
**BridgeFunction_OnTradeConfirm(index, targetIndex)**
*   `index`: User Index. "Integer"
*   `targetIndex`: Target User Index. "Integer"
*   Called on Trade OK.
*   Return: None
 
---
 
## Constants
Helper macros available in Lua:
*   `MAX_OBJECT`, `MAX_OBJECT_USER`, `MAX_OBJECT_MONSTER`
*   `OBJECT_START_USER`, `OBJECT_START_MONSTER`
*   `OBJECT_RANGE(i)`, `OBJECT_USER_RANGE(i)`, `OBJECT_MONSTER_RANGE(i)` (Functions)
 
---
*End of Documentation*
